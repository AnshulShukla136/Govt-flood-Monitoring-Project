export const formatDate = d => new Date(d).toLocaleString();
